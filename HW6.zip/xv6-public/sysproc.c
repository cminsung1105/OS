#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

extern pte_t * walkpgdir(pde_t *pgdir, const void *va, int alloc);
extern struct proc * allocproc(void);
extern int thread_create(void(*fcn)(void*), void * arg, void * stack);
extern int thread_join();
extern int thread_exit();


int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int 
sys_wrprotect(void)
{
    int size;
    char * va;

    if (argint(1,&size) < 0)
        return -1;

    if (argptr(0, &va, size) < 0)
        return -1;

    //cprintf("SYS SZ: %d\n", size);
    //cprintf("SYS VA: %d\n", va);
    
    char * a, * last;
    pte_t * pte;

    a = (char *)PGROUNDDOWN((uint)va);
    last = (char *)PGROUNDDOWN(((uint)va)+size-1);

    unsigned int pgnum = 0;
    for(;;)
    {
        if((pte=walkpgdir(myproc()->pgdir,a,1))==0)
        {
            //cprintf("no pte\n");
            return -1;
        }

        *pte &= ~PTE_W;
        //cprintf("SYS PTE: %d\n", pte);
        if (a==last)
        {
            pgnum++;
            //cprintf("finish\n");
            break;
        }
        a += PGSIZE;
        pgnum++;
    }
 
    return pgnum;
}

int 
//thread_create(void(*fcn)(void*), void * arg, void * stack)
sys_thread_create(void)
{
    void (*fcn)(void *);
    void * arg;
    void * stack;

    if(argptr(0,(void*)&fcn, sizeof(void*)) < 0)
        return -1;

    if(argptr(1, (void*)&arg, sizeof(void*)) < 0)
        return -1;

    if(argptr(2, (void*)&stack, sizeof(void*)) < 0)
        return -1;

    return thread_create(fcn, arg, stack);
}

int 
sys_thread_join(void)
{
    return thread_join();
}

int 
sys_thread_exit(void)
{
    return thread_exit();
}


/*
int 
//thread_create(void(*fcn)(void*), void * arg, void * stack)
sys_thread_create(void)
{
    void (*fcn)(void *);
    void * arg;
    void * stack;

    if(argptr(0,(void*)&fcn, sizeof(void*)) < 0)
        return -1;

    if(argptr(1, (void*)&arg, sizeof(void*)) < 0)
        return -1;

    if(argptr(2, (void*)&stack, sizeof(void*)) < 0)
        return -1;

    
    cprintf("SYS FCN: %d\n", fcn);
    cprintf("SYS ARG: %d\n", arg);
    cprintf("SYS STACK: %d\n", stack);
    

    int i, pid;
    struct proc *np;
    struct proc *curproc = myproc();

    if((np = allocproc()) == 0){
        return -1;
    }
    
    np->pgdir = curproc->pgdir;

    np->tf->esp = stack + PGSIZE;
    np->tf->esp -= sizeof(int*);
    *(int *)np->tf->esp = arg;
    np->tf->esp -= sizeof(int*);
    *(int *)np->tf->esp = 0xffffffff;

    np->sz = curproc->sz;
    np->parent = curproc;
    *np->tf = *curproc->tf;

    // Clear %eax so that fork returns 0 in the child.
    np->tf->eax = 0;

    np->tf->eip = (unsigned int)fcn;
    np->kstack = stack;

    //set the eip of the file descriptors

    for(i = 0; i < NOFILE; i++)
        if(curproc->ofile[i])
            np->ofile[i] = filedup(curproc->ofile[i]);
    np->cwd = idup(curproc->cwd);

    safestrcpy(np->name, curproc->name, sizeof(curproc->name));

    pid = np->pid;

    //spinlock?
    //acquire(&ptable.lock);

    np->state = RUNNABLE;

    //release(&ptable.lock);

    return pid;
}

int 
sys_thread_join(void)
{

  struct proc *p;
  int havekids, pid;
  struct proc *curproc = myproc();
  
  //acquire(&ptable.lock);
  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->parent != curproc)
        continue;
      havekids = 1;
      if(p->state == ZOMBIE){
        // Found one.
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->state = UNUSED;
        //release(&ptable.lock);
        return pid;
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || curproc->killed){
      release(&ptable.lock);
      return -1;
    }

    // Wait for children to exit.  (See wakeup1 call in proc_exit.)
    sleep(curproc, &ptable.lock);  //DOC: wait-sleep
  }
}

int 
sys_thread_exit(void)
{
  struct proc *curproc = myproc();
  struct proc *p;
  int fd;

  if(curproc == initproc)
    panic("init exiting");

  // Close all open files.
  for(fd = 0; fd < NOFILE; fd++){
    if(curproc->ofile[fd]){
      fileclose(curproc->ofile[fd]);
      curproc->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(curproc->cwd);
  end_op();
  curproc->cwd = 0;

  acquire(&ptable.lock);

  // Parent might be sleeping in wait().
  wakeup1(curproc->parent);

  // Pass abandoned children to init.
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->parent == curproc){
      p->parent = initproc;
      if(p->state == ZOMBIE)
        wakeup1(initproc);
    }
  }

  // Jump into the scheduler, never to return.
  curproc->state = ZOMBIE;
  sched();
  panic("zombie exit");
}


    return 3;
}
*/
