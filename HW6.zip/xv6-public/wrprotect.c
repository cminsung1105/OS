#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
    char * curaddr = sbrk(0);
    
    int size = 20000;

    sbrk(size);
    //printf(1, "USR VA: %d\n", &curaddr);

    //printf(1, "number of pages are: %d\n", wrprotect(curaddr, size));
    wrprotect(curaddr, size);

    *curaddr = 'c';

    exit();
}
