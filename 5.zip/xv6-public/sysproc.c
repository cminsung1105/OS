#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

extern pte_t * walkpgdir(pde_t *pgdir, const void *va, int alloc);


int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int 
sys_wrprotect(void)
{
    int size;
    char * va;

    if (argint(1,&size) < 0)
        return -1;

    if (argptr(0, &va, size) < 0)
        return -1;

    //cprintf("SYS SZ: %d\n", size);
    //cprintf("SYS VA: %d\n", va);
    
    char * a, * last;
    pte_t * pte;

    a = (char *)PGROUNDDOWN((uint)va);
    last = (char *)PGROUNDDOWN(((uint)va)+size-1);

    unsigned int pgnum = 0;
    for(;;)
    {
        if((pte=walkpgdir(myproc()->pgdir,a,1))==0)
        {
            //cprintf("no pte\n");
            return -1;
        }

        *pte &= ~PTE_W;
        //cprintf("SYS PTE: %d\n", pte);
        if (a==last)
        {
            pgnum++;
            //cprintf("finish\n");
            break;
        }
        a += PGSIZE;
        pgnum++;
    }
 
    return pgnum;
}
